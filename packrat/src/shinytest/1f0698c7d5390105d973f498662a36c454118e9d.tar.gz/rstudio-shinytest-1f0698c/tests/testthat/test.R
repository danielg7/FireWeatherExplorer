
context("shinytest")

test_that("shinytest works", {

  expect_true(TRUE)

})
