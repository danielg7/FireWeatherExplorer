
#' @importFrom debugme debugme

.onLoad <- function(libname, pkgname) {
  debugme()
}
