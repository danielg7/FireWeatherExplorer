
#' Test Shiny Apps
#'
#' Uses a headless browser, driven through 'WebDriver'.
#' See \code{\link{ShinyDriver}} to get started.
#'
#' @docType package
#' @name shinytest
NULL
