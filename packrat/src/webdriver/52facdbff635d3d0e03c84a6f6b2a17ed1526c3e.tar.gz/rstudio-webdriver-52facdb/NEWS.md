# 1.0.4.9000

* Make sure stdout and stderr output is recorded.

* Try to find locally-install phantomjs first.

* `Session$new()` now checks that the phantomjs binary was built with ghostdriver support.


# 1.0.3

First public release.
